# Expense Tracker • Express + MongoDB + JWT

A minimal full‑stack expense tracker with user registration/login, protected CRUD APIs, and a pretty frontend.

## Prerequisites
- Node.js 18+
- MongoDB running locally or a MongoDB Atlas connection string

## Setup

1) Unzip the project and open a terminal in the project folder.

2) Install dependencies:
```bash
npm install
```

3) Configure environment:
- Copy `.env.example` to `.env` and adjust the values.
```bash
cp .env.example .env
```
- Set `MONGODB_URI` to your MongoDB connection string.
- Optionally change `PORT` (default 4000) and `JWT_SECRET`.

4) Run the server:
```bash
npm run start
# or, with auto-restart during development
npm run dev
```

5) Open the app:
- Visit `http://localhost:4000/login.html` to register or log in.
- After login, you’ll be redirected to `/` where you can add/view/delete entries.

## API Endpoints (all JSON)
- `POST /api/auth/register` → `{ name, email, password }` → `{ token, user }`
- `POST /api/auth/login` → `{ email, password }` → `{ token, user }`
- `GET /api/entries` (auth) → list entries
- `POST /api/entries` (auth) → `{ date, amount, type }`
- `DELETE /api/entries/:id` (auth) → delete entry

## Notes
- JWT is stored in `localStorage`. For production, consider HTTPS and refresh token strategy.
- CORS is enabled but you’re serving a single origin (the same Express app).
- The frontend is intentionally simple and uses fetch().
