const express = require('express');
const jwt = require('jsonwebtoken');
const Entry = require('../models/Entry');

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret';

// Auth middleware
function auth(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
  if (!token) return res.status(401).json({ message: 'Missing token' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (e) {
    return res.status(401).json({ message: 'Invalid token' });
  }
}

// List entries for user
router.get('/', auth, async (req, res) => {
  const entries = await Entry.find({ userId: req.user.uid }).sort({ createdAt: -1 });
  res.json(entries);
});

// Create entry
router.post('/', auth, async (req, res) => {
  try {
    const { date, amount, type } = req.body;
    if (!date || !amount || !type) return res.status(400).json({ message: 'date, amount, type required' });
    const entry = await Entry.create({ userId: req.user.uid, date, amount, type });
    res.status(201).json(entry);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// Delete entry
router.delete('/:id', auth, async (req, res) => {
  try {
    const { id } = req.params;
    const deleted = await Entry.findOneAndDelete({ _id: id, userId: req.user.uid });
    if (!deleted) return res.status(404).json({ message: 'Not found' });
    res.json({ ok: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
