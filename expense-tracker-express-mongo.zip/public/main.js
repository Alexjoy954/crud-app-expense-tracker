const entryList = document.getElementById("entryList");

function getToken() {
  return localStorage.getItem('token');
}
function ensureAuth() {
  const token = getToken();
  if (!token) {
    window.location.href = '/login.html';
  } else {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    document.getElementById('userName').textContent = user.name ? `Hi, ${user.name}` : '';
  }
}
function logout() {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  window.location.href = '/login.html';
}

async function fetchEntries() {
  const token = getToken();
  const res = await fetch('/api/entries', {
    headers: { 'Authorization': `Bearer ${token}` }
  });
  if (res.status === 401) return logout();
  const data = await res.json();
  renderEntries(data);
}

async function addEntry() {
    const date = document.getElementById("dateInput").value;
    const amount = parseFloat(document.getElementById("amountInput").value);
    const type = document.getElementById("typeInput").value;
    if (!date || isNaN(amount) || amount <= 0) return alert("Please enter valid data");
    const token = getToken();
    const res = await fetch('/api/entries', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify({ date, amount, type })
    });
    if (!res.ok) return alert('Failed to add');
    document.getElementById("amountInput").value = "";
    fetchEntries();
}

async function deleteEntry(id) {
  const token = getToken();
  const res = await fetch(`/api/entries/${id}`, {
    method: 'DELETE',
    headers: { 'Authorization': `Bearer ${token}` }
  });
  if (!res.ok) return alert('Failed to delete');
  fetchEntries();
}

function renderEntries(entries) {
    entryList.innerHTML = "";
    let totalIncome = 0;
    let totalExpense = 0;
    entries.forEach((entry) => {
        const typeClass = entry.type === "expense" ? "tag-expense" : "tag-income";
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${new Date(entry.date).toISOString().slice(0,10)}</td>
            <td><span class="${typeClass}">${entry.type}</span></td>
            <td>${Number(entry.amount).toFixed(2)}</td>
            <td><button class="delete-btn" data-id="${entry._id}">✕</button></td>
        `;
        entryList.appendChild(row);
        if (entry.type === "expense") totalExpense += entry.amount;
        else totalIncome += entry.amount;
    });
    document.getElementById("totalIncome").textContent = totalIncome.toFixed(2);
    document.getElementById("totalExpense").textContent = totalExpense.toFixed(2);
    document.getElementById("netTotal").textContent = (totalIncome - totalExpense).toFixed(2);
    // wire delete buttons
    document.querySelectorAll('.delete-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const id = e.currentTarget.getAttribute('data-id');
        deleteEntry(id);
      });
    });
}

// Boot
ensureAuth();
fetchEntries();
